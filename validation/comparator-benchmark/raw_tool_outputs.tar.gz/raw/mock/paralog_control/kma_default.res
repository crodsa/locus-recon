#Template	Score	Expected	Template_length	Template_Identity	Template_Coverage	Query_Identity	Query_Coverage	Depth	q_value	p_value
mockLocus_A	   64834	       0	     507	   99.41	  100.20	   99.21	   99.80	  130.06	64834.00	1.0e-26
