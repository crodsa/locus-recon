#Template	Score	Expected	Template_length	Template_Identity	Template_Coverage	Query_Identity	Query_Coverage	Depth	q_value	p_value
mockLocus_A	    1766	       0	     507	  100.00	  100.00	  100.00	  100.00	    3.41	 1766.00	1.0e-26
