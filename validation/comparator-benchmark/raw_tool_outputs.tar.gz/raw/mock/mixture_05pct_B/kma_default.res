#Template	Score	Expected	Template_length	Template_Identity	Template_Coverage	Query_Identity	Query_Coverage	Depth	q_value	p_value
mockLocus_A	   33207	     884	     507	  100.00	  100.00	  100.00	  100.00	   63.99	30646.69	1.0e-26
mockLocus_B	    1768	   16603	     507	  100.00	  100.00	  100.00	  100.00	    3.40	11980.08	1.0e-26
