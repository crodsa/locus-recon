#Template	Score	Expected	Template_length	Template_Identity	Template_Coverage	Query_Identity	Query_Coverage	Depth	q_value	p_value
mockLocus_A	   27934	    3498	     507	  100.00	  100.00	  100.00	  100.00	   53.87	18997.14	1.0e-26
mockLocus_B	    6996	   13967	     507	  100.00	  100.00	  100.00	  100.00	   13.46	 2318.12	1.0e-26
