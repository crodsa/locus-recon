#Template	Score	Expected	Template_length	Template_Identity	Template_Coverage	Query_Identity	Query_Coverage	Depth	q_value	p_value
mockLocus_A	   17422	    8743	     507	  100.00	  100.00	  100.00	  100.00	   33.66	 2878.46	1.0e-26
mockLocus_B	   17487	    8711	     507	  100.00	  100.00	  100.00	  100.00	   33.77	 2939.85	1.0e-26
