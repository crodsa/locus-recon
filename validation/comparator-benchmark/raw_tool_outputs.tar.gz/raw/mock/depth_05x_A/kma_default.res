#Template	Score	Expected	Template_length	Template_Identity	Template_Coverage	Query_Identity	Query_Coverage	Depth	q_value	p_value
mockLocus_A	    2900	       0	     507	  100.00	  100.00	  100.00	  100.00	    5.59	 2900.00	1.0e-26
