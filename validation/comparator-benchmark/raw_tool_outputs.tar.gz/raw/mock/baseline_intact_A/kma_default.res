#Template	Score	Expected	Template_length	Template_Identity	Template_Coverage	Query_Identity	Query_Coverage	Depth	q_value	p_value
mockLocus_A	   23268	       0	     507	  100.00	  100.00	  100.00	  100.00	   44.85	23268.00	1.0e-26
