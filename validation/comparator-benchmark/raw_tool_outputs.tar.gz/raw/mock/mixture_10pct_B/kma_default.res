#Template	Score	Expected	Template_length	Template_Identity	Template_Coverage	Query_Identity	Query_Coverage	Depth	q_value	p_value
mockLocus_A	   31604	    1761	     507	  100.00	  100.00	  100.00	  100.00	   60.91	26691.49	1.0e-26
mockLocus_B	    3523	   15802	     507	  100.00	  100.00	  100.00	  100.00	    6.78	 7802.01	1.0e-26
