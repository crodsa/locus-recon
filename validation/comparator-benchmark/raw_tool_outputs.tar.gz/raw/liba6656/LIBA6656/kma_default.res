#Template	Score	Expected	Template_length	Template_Identity	Template_Coverage	Query_Identity	Query_Coverage	Depth	q_value	p_value
B7_6	  444713	    6067	    7104	   99.99	  100.00	   99.99	  100.00	   62.60	426837.78	1.0e-26
B7_9	  654008	    4163	    7104	   99.93	   99.94	   99.99	  100.06	   92.10	641621.42	1.0e-26
B10_1	    8532	   10029	    7101	    8.18	    8.22	   99.49	 1215.92	    1.18	  120.83	1.0e-26
